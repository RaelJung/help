`{$blog.title}` — displays the title of the blog

`{$blog.desc}` — displays the blog description

`{$blog.posts}` — array with the posts of the blog

`{$post}` — array with the data of current post

`{$prev.url}` — address of the previous page of the pagination

`{$next.url}` — address of the next page of the pagination

`{$latestPosts}` — array with the latest posts

`{$allTags}` — array with all tags