<?php
namespace Inc\Modules\Devbar;

class Dump
{
    public static $data = [];
}
