This module displays images from the selected photo gallery. Paste code below in the template or in the page content:

`{$carousel.gallery-name}`

After that, change `gallery-name` to chosen gallery slug.